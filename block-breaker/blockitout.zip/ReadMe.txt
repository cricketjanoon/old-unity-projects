This font is free for any use, but if using it for anything other than personal use, please let me know by messaging me at
http://www.graphicsbykateri.tumblr.com/ask. 

Thank you and enjoy.